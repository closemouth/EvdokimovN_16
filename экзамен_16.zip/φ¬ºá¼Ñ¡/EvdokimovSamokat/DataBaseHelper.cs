﻿< Page x: Class = "EvdokimovSamokat.DataBaseHelper"
      xmlns = "http://schemas.microsoft.com/winfx/2006/xaml/presentation"
      xmlns: x = "http://schemas.microsoft.com/winfx/2006/xaml"
      xmlns: mc = "http://schemas.openxmlformats.org/markup-compatibility/2006"
      xmlns: d = "http://schemas.microsoft.com/expression/blend/2008"
      xmlns: local = "clr-namespace:EvdokimovSamokat"
      mc: Ignorable = "d"
      d: DesignHeight = "450" d: DesignWidth = "800"
      Title = "DataBaseHelper" >

    < Grid >


    </ Grid >
</ Page >
