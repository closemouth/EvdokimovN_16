﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EvdokimovSamokat
{
    public class DatabaseHelper
    {
        private EvdokimovNsamokatEntities db = new EvdokimovNsamokatEntities();

        // Получение списка моделей самокатов
        public List<string> GetScooterModels()
        {
            return db.Модели_самокатов.Select(m => m.название).ToList();
        }

        // Проверка авторизации пользователя
        public bool AuthenticateUser(string login, string password)
        {
            return db.Пользователи.Any(u => u.логин == login && u.пароль == password);
        }

        // Получение ID пользователя по логину
        public int GetUserIdByLogin(string login)
        {
            return db.Пользователи.FirstOrDefault(u => u.логин == login)?.id ?? 0;
        }

        // Получение ID самоката по названию
        public int GetScooterIdByName(string scooterName)
        {
            return db.Модели_самокатов.FirstOrDefault(m => m.название == scooterName)?.id ?? 0;
        }

        // Создание нового заказа
        public void CreateOrder(int userId, int scooterId, DateTime startDate, DateTime endDate)
        {
            var order = new Аренды
            {
                пользователь_id = userId,
                самокат_id = scooterId,
                пункт_выдачи_id = 1, // Например, первый пункт проката
                дата_начала = startDate,
                дата_окончания = endDate,
                статус = "активна"
            };
            db.Аренды.Add(order);
            db.SaveChanges();
        }
    }
}