﻿using System;
using System.Windows;

namespace EvdokimovSamokat
{
    public partial class OrderWindow : Window
    {
        private DatabaseHelper dbHelper = new DatabaseHelper();
        private int userId;

        public OrderWindow(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            LoadScooters();
        }

        private void LoadScooters()
        {
            ScooterComboBox.ItemsSource = dbHelper.GetScooterModels();
        }

        private void OrderButton_Click(object sender, RoutedEventArgs e)
        {
            string selectedScooter = ScooterComboBox.SelectedItem?.ToString();
            DateTime? startDate = StartDatePicker.SelectedDate;
            DateTime? endDate = EndDatePicker.SelectedDate;

            if (string.IsNullOrEmpty(selectedScooter) || startDate == null || endDate == null)
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            int scooterId = dbHelper.GetScooterIdByName(selectedScooter);

            if (scooterId == 0)
            {
                MessageBox.Show("Выбран недопустимый самокат.");
                return;
            }

            dbHelper.CreateOrder(userId, scooterId, startDate.Value, endDate.Value);
            MessageBox.Show("Заказ успешно оформлен!");
            this.Close();
        }
    }
}