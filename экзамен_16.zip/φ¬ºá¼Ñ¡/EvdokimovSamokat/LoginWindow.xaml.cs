﻿using System.Windows;
using System.Windows.Controls;

namespace EvdokimovSamokat
{
    public partial class LoginWindow : Window
    {
        private DatabaseHelper dbHelper = new DatabaseHelper();
        public int AuthenticatedUserId { get; private set; }

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginBox.Text;
            string password = PasswordBox.Password;

            if (dbHelper.AuthenticateUser(login, password))
            {
                AuthenticatedUserId = dbHelper.GetUserIdByLogin(login);
                this.DialogResult = true;
                this.Close();
            }
            else
            {
                ErrorMessage.Text = "Неверный логин или пароль.";
                ErrorMessage.Visibility = Visibility.Visible;
            }
        }
    }
}