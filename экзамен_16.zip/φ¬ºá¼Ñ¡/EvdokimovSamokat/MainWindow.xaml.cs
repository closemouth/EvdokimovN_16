﻿using EvdokimovSamokat;
using System.Windows;

namespace EvdokimovSamokat
{
    public partial class MainWindow : Window
    {
        private DatabaseHelper dbHelper = new DatabaseHelper();

        public MainWindow()
        {
            InitializeComponent();
            LoadScooters();
        }

        private void LoadScooters()
        {
            ScooterList.ItemsSource = dbHelper.GetScooterModels();
        }

        private void OrderButton_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow();
            if (loginWindow.ShowDialog() == true)
            {
                OrderWindow orderWindow = new OrderWindow(loginWindow.AuthenticatedUserId);
                orderWindow.ShowDialog();
            }
        }
    }
}